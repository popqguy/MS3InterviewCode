package maven.SQLite.TestDB;

public class Person {
	String A;
	String B;
	String C;
	String D;
	String E;
	String F;
	String G;
	String H;
	String I;
	String J;
	boolean incompleteRecord;

	public Person(String[] newRow) {
		A = newRow[0];
		B = newRow[1];
		C = newRow[2];
		D = newRow[3];
		E = newRow[4];
		F = newRow[5];
		G = newRow[6];
		H = newRow[7];
		I = newRow[8];
		J = newRow[9];
		incompleteRecord = false;
	}
}
