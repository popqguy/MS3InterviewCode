package maven.SQLite.TestDB;

public class Person {
	String A;
	String B;
	String C;
	String D;
	String E;
	String F;
	String G;
	boolean H;
	boolean I;
	String J;
	boolean incompleteRecord;

	public Person(String[] newRow) {
		A = newRow[0];
		B = newRow[1];
		C = newRow[2];
		D = newRow[3];
		E = newRow[4];
		F = newRow[5];
		G = newRow[6];
		if (newRow[7].trim().equals("true")) {
			H = true;
		} else if (newRow[7].trim().equals("false")) {
			H = false;
		}
		
		if (newRow[8].trim().equals("true")) {
			I = true;
		} else if (newRow[8].trim().equals("false")) {
			I = false;
		}
		
		J = newRow[9];
		incompleteRecord = false;
	}
}
