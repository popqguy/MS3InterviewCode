package maven.SQLite.TestDB;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import com.opencsv.CSVReader;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Shell;

public class CSVParse {
//	DMM: Declaration of various objects at the class level since they are used throughout.
	static String inputFileName = "";
	static CSVReader csvReader;
	static Connection dbConnection = null;
	
/*
	DMM: The main method parses through the provided CSV file, 
	instantiates the Person class and assigns each record to different array lists according to whether or not they are missing data, 
	and creates a log file, a bad records CSV file, and a database containing the complete records.
*/
	public static void main(String[] args) throws Exception {

//		DMM: This section asks the user for the file name used for input and formats the other file names accordingly.
		openInputWindow();
		String badDataFileName = inputFileName.substring(0, inputFileName.lastIndexOf(".csv")).concat("-bad.csv");
		String logFileName = inputFileName.substring(0, inputFileName.lastIndexOf(".csv")).concat(".log");
		String dbFileName = inputFileName.substring(0, inputFileName.lastIndexOf(".csv")).concat(".db");
		
//		DMM: Instantiations that are used in parsing through the provided CSV file.
		String[] currentRow = null;
		try {
		csvReader = new CSVReader(new FileReader(inputFileName));
		} catch (Exception e) {
			System.out.println("Error in writing to log file.");
			JFrame outputWindow = new JFrame();
			JOptionPane.showMessageDialog(outputWindow, "Please enter an existent file name.", "Error", JOptionPane.ERROR_MESSAGE);
			System.exit(0);
		}
//		DMM: Instantiations that are used in recording and assigning the records depending on missing data.
		ArrayList<Person> goodData = new ArrayList<Person>();
		ArrayList<Person> badData = new ArrayList<Person>();
		
//		DMM: Instantiations that are used for record keeping for the output log.
		int totalRecordsCount = 0;
		int dbRecordsCount = 0;

//		DMM: Instantiations that are used in creating the output log file.
		File logFile = new File(logFileName);
		FileWriter logWriter = new FileWriter(logFileName);

//		DMM: The code below establishes the connection to a pre-existing database file or creates a new one if it is non-existent.
		try {
			Class.forName("org.sqlite.JDBC");
			dbConnection = DriverManager.getConnection("jdbc:sqlite:" + dbFileName);
		} catch (SQLException e) {
			System.out.println("Error in setting up the database.");
			JFrame outputWindow = new JFrame();
			JOptionPane.showMessageDialog(outputWindow, "Failed to create or connect to database.", "Error", JOptionPane.ERROR_MESSAGE);
			System.exit(0);
		}

//		DMM: Instantiations that are used in creating the CSV file which records each incomplete record.
		currentRow = csvReader.readNext();
		File csvFile = new File(badDataFileName);
		FileWriter csvWriter = new FileWriter(badDataFileName);
		csvWriterSetup(csvFile, csvWriter, currentRow);
		
//		DMM: Calls the method which drops any existing data then creates a new one with columns corresponding to the CSV provided.
		initializeTable(dbConnection, currentRow);

//		DMM: While loop which parses through each record in the provided CSV file.
		while((currentRow = csvReader.readNext()) != null) {
			Person newPerson = new Person(currentRow);
			totalRecordsCount++;
			
//			DMM: Loops through each record's data to check for incompleteness.
			for (int i = 0; i <= 9; i++) {
				if (currentRow[i].isEmpty()) {
					newPerson.incompleteRecord = true;
				}
			}
			
//			DMM: Adds complete records to the array of data to be added to the database, adds incomplete records to the bad data CSV file.
			if (newPerson.incompleteRecord == false) {
				goodData.add(newPerson);
			} else if (newPerson.incompleteRecord == true) {
				badData.add(newPerson);
//				DMM: I added in quotes to ensure that the entire image file column is treated as one string, 
//						as they contain commas and would be treated as a delimiter otherwise.
				csvWriter.append("\"");
				csvWriter.append(String.join("\",\"", currentRow));
				csvWriter.append("\"\n");
			}
		}

//		DMM: For each record in the array list, execute the insert method to add that record to the database.
//				Also keeps track of total records added.
		for (Person currentPerson : goodData) {
			insert(dbConnection, currentPerson);
			dbRecordsCount++;
		}

//		DMM: Executes the method which adds the totals to the log file.
		logKeeper(logFile, logWriter, totalRecordsCount, dbRecordsCount, badData);
		
//		DMM: Output window as indication of successful completion.
		JFrame outputWindow = new JFrame();
		JOptionPane.showMessageDialog(outputWindow, "The operation was completed successfully!", "Mission Complete", JOptionPane.INFORMATION_MESSAGE);
		
//		DMM: Clears caches for both file writers and closes them, closes the application.
		csvWriter.flush();
		csvWriter.close();
		logWriter.flush();
		logWriter.close();
		System.exit(0);
	}
	
//	DMM: This method sets up the table in the database to ensure it is ready to accept the complete records. Passes the database connection.
	public static Connection initializeTable(Connection currentConnection, String[] firstRow) throws Exception {
//		DMM: Error trapping for the SQL statements.
		try {
//			DMM: This section checks the database file for an existing person table and drops it if so.
			String sqlDrop = "DROP TABLE IF EXISTS person;";
			Statement stmtDrop = currentConnection.createStatement();
			stmtDrop.execute(sqlDrop);
			
//			DMM: This section creates the person table in the database.
			String sqlTable = "CREATE TABLE IF NOT EXISTS person (\n"
						+ "		".concat(firstRow[0]).concat(" string,\n")
						+ "		".concat(firstRow[1]).concat(" string,\n")
						+ "		".concat(firstRow[2]).concat(" string,\n")
						+ "		".concat(firstRow[3]).concat(" string,\n")
						+ "		".concat(firstRow[4]).concat(" string,\n")
						+ "		".concat(firstRow[5]).concat(" string,\n")
						+ "		".concat(firstRow[6]).concat(" string,\n")
						+ "		".concat(firstRow[7]).concat(" boolean,\n")
						+ "		".concat(firstRow[8]).concat(" boolean,\n")
						+ "		".concat(firstRow[9]).concat(" string\n")
						+ ");";
			Statement stmtTable = currentConnection.createStatement();
			stmtTable.execute(sqlTable);
		} catch (SQLException e) {
			System.out.println("Error in creating the table.");
			JFrame outputWindow = new JFrame();
			JOptionPane.showMessageDialog(outputWindow, "Failed to set up the person table.", "Error", JOptionPane.ERROR_MESSAGE);
			System.exit(0);
		}
		return currentConnection;
	}

//	DMM: This method resides in the for each loop and passes the database connection and current person object.
//			It then uses the attributes of that person object and adds that record in the person table.
	public static void insert(Connection currentConnection, Person myPerson) {
		try {
			String sqlInsert = "INSERT INTO person(A,B,C,D,E,F,G,H,I,J) VALUES(?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement pstmtInsert = currentConnection.prepareStatement(sqlInsert);
			pstmtInsert.setString(1, myPerson.A);
			pstmtInsert.setString(2, myPerson.B);
			pstmtInsert.setString(3, myPerson.C);
			pstmtInsert.setString(4, myPerson.D);
			pstmtInsert.setString(5, myPerson.E);
			pstmtInsert.setString(6, myPerson.F);
			pstmtInsert.setString(7, myPerson.G);
			pstmtInsert.setBoolean(8, myPerson.H);
			pstmtInsert.setBoolean(9, myPerson.I);
			pstmtInsert.setString(10, myPerson.J);
			pstmtInsert.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Error in inserting data into table.");
			JFrame outputWindow = new JFrame();
			JOptionPane.showMessageDialog(outputWindow, "Failed to insert records into database.", "Error", JOptionPane.ERROR_MESSAGE);
			System.exit(0);
		}
	}

//	DMM: This method sets up the CSV bad data file and creates the corresponding columns.
	public static FileWriter csvWriterSetup(File mycsvFile, FileWriter mycsvWriter, String[] firstRow) {
		if (mycsvFile.isFile()) {
			try {
				mycsvWriter.append(firstRow[0] + ",");
				mycsvWriter.append(firstRow[1] + ",");
				mycsvWriter.append(firstRow[2] + ",");
				mycsvWriter.append(firstRow[3] + ",");
				mycsvWriter.append(firstRow[4] + ",");
				mycsvWriter.append(firstRow[5] + ",");
				mycsvWriter.append(firstRow[6] + ",");
				mycsvWriter.append(firstRow[7] + ",");
				mycsvWriter.append(firstRow[8] + ",");
				mycsvWriter.append(firstRow[9] + ",");
				mycsvWriter.append("\n");
			} catch(IOException e) {
				System.out.println("Error in setting up csv file for output.");
				JFrame outputWindow = new JFrame();
				JOptionPane.showMessageDialog(outputWindow, "Failed to set up CSV file.", "Error", JOptionPane.ERROR_MESSAGE);
				System.exit(0);
			}
		}
		return mycsvWriter;
	}

//	DMM: This method writes to the output log file. It first checks that the file exists and then logs total records, 
//			total incomplete records, and total records that were written to the person table.
	public static FileWriter logKeeper(File myLogFile, FileWriter myLogWriter, int myTotalRecords, 
			int myGoodRecords, ArrayList<Person> myBadData) {
		if (myLogFile.isFile()) {
			try {
				myLogWriter.append("Number of records received: " + myTotalRecords + "\n");
				myLogWriter.append("Number of records successfully written to database: " + myGoodRecords + "\n");
				myLogWriter.append("Number of records with incomplete data: " + myBadData.size() + "\n");
			} catch (IOException e) {
				System.out.println("Error in writing to log file.");
				JFrame outputWindow = new JFrame();
				JOptionPane.showMessageDialog(outputWindow, "Failed to write to log file.", "Error", JOptionPane.ERROR_MESSAGE);
				System.exit(0);
			}
		}
		return myLogWriter;
	}
	
//	DMM: This method prompts the user for the input file name.
	public static void openInputWindow() {
		FileDialog filePick = new FileDialog(new Shell(), SWT.OPEN);
		filePick.setFilterPath("C:\\");
		filePick.setFilterExtensions(new String[] {"*.csv"});
		inputFileName = filePick.open();
		
		JFrame inputWindow = new JFrame();
//		DMM: Exit application if user does not give input
		if (inputFileName == null) {
			JOptionPane.showMessageDialog(inputWindow, "Please enter a file name.", "Warning", JOptionPane.WARNING_MESSAGE);
			System.exit(0);
		}
	}

}


